##### Update variables at path vars/main.yml
### Run playbook
ansible-playbook -i hosts dynatrace-windows/main.yaml
